<?php $__env->startSection('title', 'Xəstələr'); ?>

<?php $__env->startSection('nav-menu'); ?>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('doctor.dashboard')); ?>">Ana Səhifə</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('doctor.patients')); ?>">Xəstələr</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('doctor.patients.create')); ?>">Yeni Xəstə</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('doctor.referrals')); ?>">Göndərişlər</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h1 class="fw-bold text-dark mb-2">Xəstələrim</h1>
        <p class="text-muted">Qeydiyyatdan keçirdiyiniz xəstələr</p>
    </div>

    <div class="mb-3">
        <a href="<?php echo e(route('doctor.patients.create')); ?>" class="btn btn-primary">
            <i class="bi bi-person-plus"></i> Yeni Xəstə Əlavə Et
        </a>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if($patients->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="fw-semibold"><i class="bi bi-hash"></i> ID</th>
                                <th class="fw-semibold"><i class="bi bi-person"></i> Ad Soyad</th>
                                <th class="fw-semibold d-none d-md-table-cell"><i class="bi bi-credit-card"></i> FIN Kod</th>
                                <th class="fw-semibold d-none d-md-table-cell"><i class="bi bi-telephone"></i> Telefon</th>
                                <th class="fw-semibold d-none d-lg-table-cell"><i class="bi bi-file-medical"></i> Göndərişlər</th>
                                <th class="fw-semibold d-none d-lg-table-cell"><i class="bi bi-calendar"></i> Qeydiyyat Tarixi</th>
                                <th class="fw-semibold">Əməliyyat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="fw-bold text-primary">#<?php echo e($patient->id); ?></td>
                                    <td>
                                        <div class="fw-semibold"><?php echo e($patient->full_name); ?></div>
                                        <div class="d-md-none small text-muted mt-1">
                                            <div><i class="bi bi-credit-card"></i> <?php echo e($patient->serial_number ?? '-'); ?></div>
                                            <div><i class="bi bi-telephone"></i> <?php echo e($patient->phone); ?></div>
                                        </div>
                                    </td>
                                    <td class="d-none d-md-table-cell fw-semibold"><?php echo e($patient->serial_number ?? '-'); ?></td>
                                    <td class="d-none d-md-table-cell"><?php echo e($patient->phone); ?></td>
                                    <td class="d-none d-lg-table-cell">
                                        <span class="badge bg-info text-dark"><?php echo e($patient->referrals_count); ?> göndəriş</span>
                                    </td>
                                    <td class="d-none d-lg-table-cell text-muted"><?php echo e($patient->created_at->format('d.m.Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('doctor.referrals.create', $patient->id)); ?>" class="btn btn-primary btn-sm">
                                            <i class="bi bi-plus-circle"></i> <span class="d-none d-sm-inline">Göndəriş</span>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-3">
                    <?php echo e($patients->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center text-muted py-5">
                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                    <p>Hələ xəstə qeydiyyatdan keçirməmisiniz</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/doctor/patients/index.blade.php ENDPATH**/ ?>