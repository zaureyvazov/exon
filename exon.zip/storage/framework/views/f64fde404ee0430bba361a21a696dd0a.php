

<?php $__env->startSection('title', 'Endirimli Göndərişlər'); ?>

<?php $__env->startSection('nav-menu'); ?>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Ana Səhifə</a></li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
            Göndərişlər
        </a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo e(route('admin.referrals.non-discounted')); ?>">Endirimsiz</a></li>
            <li><a class="dropdown-item active" href="<?php echo e(route('admin.referrals.discounted')); ?>">Endirimli</a></li>
        </ul>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h1 class="h3 fw-bold">Endirimli Göndərişlər</h1>
        <p class="text-muted">Endirim tətbiq edilmiş bütün göndərişlər</p>
    </div>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.referrals.discounted')); ?>">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Başlanğıc Tarix</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Bitmə Tarix</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Həkim</label>
                        <select name="doctor_id" class="form-select">
                            <option value="">Hamısı</option>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($doctor->id); ?>" <?php echo e(request('doctor_id') == $doctor->id ? 'selected' : ''); ?>>
                                    Dr. <?php echo e($doctor->name); ?> <?php echo e($doctor->surname); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Xəstə Axtarışı</label>
                        <input type="text" name="search" class="form-control" placeholder="Ad, FIN..." value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-filter"></i> Filtrele</button>
                        <a href="<?php echo e(route('admin.referrals.discounted')); ?>" class="btn btn-outline-secondary">Təmizlə</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if($referrals->count() > 0): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Həkim</th>
                            <th>Xəstə</th>
                            <th>Analizlər</th>
                            <th>Qiymət</th>
                            <th>Endirim</th>
                            <th>Komissiya</th>
                            <th>Status</th>
                            <th>Tarix</th>
                            <th>Əməliyyat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-warning">
                            <td><span class="badge bg-secondary">#<?php echo e($referral->id); ?></span></td>
                            <td>
                                <div class="fw-semibold">Dr. <?php echo e($referral->doctor->name); ?></div>
                                <small class="text-muted"><?php echo e($referral->doctor->surname); ?></small>
                            </td>
                            <td>
                                <div><?php echo e($referral->patient->full_name); ?></div>
                                <strong><?php echo e($referral->patient->name); ?> <?php echo e($referral->patient->father_name); ?> <?php echo e($referral->patient->surname); ?></strong>
                                <?php if($referral->patient->serial_number): ?>
                                    <br><small class="text-muted"><?php echo e($referral->patient->serial_number); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $totalAnalyses = $referral->analyses->count();
                                    $cancelledCount = $referral->analyses->filter(fn($a) => $a->pivot->is_cancelled ?? false)->count();
                                    $activeCount = $totalAnalyses - $cancelledCount;
                                ?>
                                <span class="badge bg-info"><?php echo e($activeCount); ?> aktiv</span>
                                <?php if($cancelledCount > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($cancelledCount); ?> ləğv</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-bold text-success"><?php echo e(number_format($referral->final_price, 2)); ?> AZN</div>
                                <small class="text-muted"><s><?php echo e(number_format($referral->total_price, 2)); ?> AZN</s></small>
                                <div><small class="text-muted">Vergi daxil: <?php echo e(number_format($referral->final_price_with_tax, 2)); ?> AZN</small></div>
                            </td>
                            <td>
                                <?php if($referral->discount_type === 'percentage'): ?>
                                    <span class="badge bg-warning text-dark"><?php echo e($referral->discount_value); ?>%</span>
                                <?php elseif($referral->discount_type === 'amount'): ?>
                                    <span class="badge bg-warning text-dark"><?php echo e(number_format($referral->discount_value, 2)); ?> AZN</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($referral->is_priced && $referral->doctor_commission): ?>
                                    <span class="fw-bold text-success"><?php echo e(number_format($referral->doctor_commission, 2)); ?> AZN</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Təyin olunmayıb</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($referral->is_approved): ?>
                                    <span class="badge bg-success">Təsdiqlənib</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">Gözləyir</span>
                                <?php endif; ?>
                            </td>
                            <td><small><?php echo e($referral->created_at->format('d.m.Y H:i')); ?></small></td>
                            <td>
                                <div class="d-flex gap-1">
                                    <a href="<?php echo e(route('admin.referrals.show', $referral->id)); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i> Bax
                                    </a>
                                    <?php if(!$referral->is_priced): ?>
                                    <button type="button" class="btn btn-sm btn-success" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#commissionModal<?php echo e($referral->id); ?>">
                                        <i class="bi bi-cash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Commission Modals -->
    <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!$referral->is_priced): ?>
    <div class="modal fade" id="commissionModal<?php echo e($referral->id); ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.discounted.setCommission', $referral->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-cash"></i> Komissiya Təyin Et</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-info">
                            <strong>Göndəriş #<?php echo e($referral->id); ?></strong><br>
                            Xəstə: <?php echo e($referral->patient->full_name); ?><br>
                            Həkim: Dr. <?php echo e($referral->doctor->name); ?> <?php echo e($referral->doctor->surname); ?>

                        </div>

                        <div class="card bg-light mb-3">
                            <div class="card-body">
                                <div class="row g-2">
                                    <div class="col-6">
                                        <small class="text-muted">Orijinal Qiymət:</small>
                                        <div class="fw-bold"><?php echo e(number_format($referral->total_price, 2)); ?> AZN</div>
                                    </div>
                                    <div class="col-6">
                                        <small class="text-muted">Final Qiymət:</small>
                                        <div class="fw-bold text-success"><?php echo e(number_format($referral->final_price, 2)); ?> AZN</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Həkim Komissiyası (AZN) <span class="text-danger">*</span></label>
                            <input type="number" name="doctor_commission" class="form-control" step="0.01" min="0" 
                                   max="<?php echo e($referral->final_price); ?>" required placeholder="Məsələn: 10.50">
                            <small class="text-muted">Maksimum: <?php echo e(number_format($referral->final_price, 2)); ?> AZN</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Ləğv Et</button>
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle"></i> Təyin Et
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="mt-3">
        <?php echo e($referrals->links()); ?>

    </div>
    <?php else: ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-5">
            <i class="bi bi-inbox fs-1 text-muted d-block mb-3"></i>
            <p class="text-muted">Endirimli göndəriş tapılmadı</p>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/admin/referrals/discounted.blade.php ENDPATH**/ ?>