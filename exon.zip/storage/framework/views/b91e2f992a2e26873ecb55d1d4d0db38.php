<?php
    use App\Models\Setting;
    $canSeePrices = Setting::doctorCanSeePrices();
?>



<?php $__env->startSection('title', 'Yeni Göndəriş'); ?>

<?php $__env->startSection('nav-menu'); ?>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('doctor.dashboard')); ?>"><i class="bi bi-house-door"></i> Ana Səhifə</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('doctor.patients')); ?>"><i class="bi bi-people"></i> Xəstələr</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('doctor.patients.create')); ?>"><i class="bi bi-person-plus"></i> Yeni Xəstə</a></li>
    <li class="nav-item"><a class="nav-link active" href="<?php echo e(route('doctor.referrals')); ?>"><i class="bi bi-file-medical"></i> Göndərişlər</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h1 class="h3 fw-bold mb-1">Yeni Göndəriş Yarat</h1>
        <div class="text-muted">Xəstə üçün analiz göndərişi yaradın</div>
    </div>

    <div class="row justify-content-center">
        <div class="col-12 col-xl-10">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <form action="<?php echo e(route('doctor.referrals.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label class="form-label fw-semibold" for="patient_id">Xəstə Seçin *</label>
                            <select
                                id="patient_id"
                                name="patient_id"
                                class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                required
                                <?php echo e($patient ? 'disabled' : ''); ?>

                            >
                                <option value="">Xəstə seçin...</option>
                                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e((old('patient_id', $patient?->id) == $p->id) ? 'selected' : ''); ?>>
                                        <?php echo e($p->name); ?> <?php echo e($p->father_name); ?> <?php echo e($p->surname); ?> <?php if($p->serial_number): ?> - <?php echo e($p->serial_number); ?> <?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($patient): ?>
                                <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                            <?php endif; ?>
                            <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                            <label class="form-label fw-semibold mb-0">Analizlər Seçin *</label>
                            <span id="selectedCount" class="badge bg-primary-subtle text-primary border border-primary-subtle"></span>
                        </div>
                        <?php $__errorArgs = ['analyses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mb-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="mb-3">
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0">
                                    <i class="bi bi-search text-muted"></i>
                                </span>
                                <input
                                    type="text"
                                    id="searchAnalysis"
                                    class="form-control border-start-0 ps-0"
                                    placeholder="Analiz adı ilə axtarın..."
                                >
                            </div>
                        </div>

                        <div class="row g-3">
                            <!-- Sol tərəf - Kateqoriyalar -->
                            <div class="col-md-4">
                                <div class="card border">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0 fw-semibold">
                                            <i class="bi bi-folder2"></i> Analiz Növləri
                                        </h6>
                                    </div>
                                    <div class="list-group list-group-flush" style="max-height: 400px; overflow-y: auto;" id="categoryList">
                                        <button type="button" class="list-group-item list-group-item-action category-filter active" data-category="all">
                                            <i class="bi bi-grid-3x3-gap"></i> Hamısı
                                            <span class="badge bg-primary float-end"><?php echo e($analyses->flatten()->count()); ?></span>
                                        </button>
                                        <?php $__currentLoopData = $analyses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $categoryAnalyses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button type="button" class="list-group-item list-group-item-action category-filter" data-category="<?php echo e($categoryName); ?>">
                                                <i class="bi bi-folder2"></i> <?php echo e($categoryName); ?>

                                                <span class="badge bg-secondary float-end"><?php echo e($categoryAnalyses->count()); ?></span>
                                            </button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Sağ tərəf - Analizlər -->
                            <div class="col-md-8">
                                <div class="card border">
                                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0 fw-semibold">
                                            <i class="bi bi-clipboard-pulse"></i> <span id="categoryTitle">Bütün Analizlər</span>
                                        </h6>
                                        <div class="btn-group btn-group-sm">
                                            <button type="button" class="btn btn-outline-primary btn-sm" id="selectAllBtn">
                                                <i class="bi bi-check-all"></i> Hamısını seç
                                            </button>
                                            <button type="button" class="btn btn-outline-secondary btn-sm" id="deselectAllBtn">
                                                <i class="bi bi-x"></i> Heç birini
                                            </button>
                                        </div>
                                    </div>
                                    <div class="list-group list-group-flush" style="max-height: 400px; overflow-y: auto;" id="analysisList">
                                        <?php $__currentLoopData = $analyses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $categoryAnalyses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $categoryAnalyses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="list-group-item list-group-item-action analysis-item"
                                                       data-name="<?php echo e(strtolower($analysis->name)); ?>"
                                                       data-category="<?php echo e($categoryName); ?>"
                                                       data-analysis-id="<?php echo e($analysis->id); ?>">
                                                    <div class="d-flex align-items-center gap-3">
                                                        <input
                                                            type="checkbox"
                                                            class="form-check-input mt-0 flex-shrink-0 analysis-checkbox"
                                                            name="analyses[]"
                                                            value="<?php echo e($analysis->id); ?>"
                                                            id="analysis_<?php echo e($analysis->id); ?>"
                                                            <?php echo e(old('analyses') && in_array($analysis->id, old('analyses')) ? 'checked' : ''); ?>

                                                        >
                                                        <div class="flex-grow-1">
                                                            <div class="d-flex justify-content-between align-items-start gap-2">
                                                                <div>
                                                                    <div class="fw-semibold"><?php echo e($analysis->name); ?></div>
                                                                    <div class="small text-muted">
                                                                        <i class="bi bi-folder2"></i> <?php echo e($categoryName); ?>

                                                                    </div>
                                                                </div>
                                                                <?php if($canSeePrices): ?>
                                                                    <span class="badge bg-info-subtle text-info border border-info"><?php echo e(number_format($analysis->price, 2)); ?> AZN</span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <label class="form-label fw-semibold" for="notes">Qeydlər (İstəyə bağlı)</label>
                            <textarea
                                id="notes"
                                name="notes"
                                class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                rows="4"
                                placeholder="Əlavə qeydlər..."
                            ><?php echo e(old('notes')); ?></textarea>
                            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-flex gap-2 flex-wrap mt-4">
                            <button type="submit" class="btn btn-success" id="submitBtn">
                                <i class="bi bi-save"></i> Göndərişi Yarat
                            </button>
                            <a href="<?php echo e(route('doctor.dashboard')); ?>" class="btn btn-outline-secondary">
                                <i class="bi bi-arrow-left"></i> Geri
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .category-filter {
        cursor: pointer;
        transition: all 0.2s;
    }

    .category-filter:hover {
        background-color: #f8f9fa !important;
    }

    .category-filter.active {
        background-color: #0d6efd !important;
        color: white !important;
        border-color: #0d6efd !important;
    }

    .category-filter.active .badge {
        background-color: white !important;
        color: #0d6efd !important;
    }

    .analysis-item {
        cursor: pointer;
        transition: all 0.2s;
    }

    .analysis-item:hover {
        background-color: #f8f9fa;
    }

    .analysis-checkbox:checked + .flex-grow-1 {
        opacity: 1;
    }

    .analysis-checkbox:not(:checked) + .flex-grow-1 {
        opacity: 0.6;
    }

    /* Mobile responsiveness */
    @media (max-width: 767.98px) {
        #categoryList {
            max-height: 200px !important;
        }

        #analysisList {
            max-height: 300px !important;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const selectedCountEl = document.getElementById('selectedCount');
        const searchInput = document.getElementById('searchAnalysis');
        const analysisItems = document.querySelectorAll('.analysis-item');
        const form = document.querySelector('form');
        const submitBtn = document.getElementById('submitBtn');
        let isSubmitting = false;

        // Form submit handling - prevent double submission and fix back button
        if (form && submitBtn) {
            form.addEventListener('submit', function(e) {
                // Validation: at least one analysis must be selected
                const checkedAnalyses = document.querySelectorAll('input[name="analyses[]"]:checked');
                if (checkedAnalyses.length === 0) {
                    e.preventDefault();
                    alert('Zəhmət olmasa ən azı bir analiz seçin');
                    return false;
                }

                if (isSubmitting) {
                    e.preventDefault();
                    return false;
                }

                isSubmitting = true;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Göndərilir...';
            });

            // Fix browser back/forward cache issue
            window.addEventListener('pageshow', function(event) {
                if (event.persisted || (window.performance && performance.getEntriesByType("navigation")[0]?.type === 'back_forward')) {
                    isSubmitting = false;
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="bi bi-save"></i> Göndərişi Yarat';
                }
            });

            // Reset on page unload
            window.addEventListener('beforeunload', function() {
                if (!isSubmitting) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="bi bi-save"></i> Göndərişi Yarat';
                }
            });
        }

        // Axtarma funksiyası
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase().trim();
                const activeCategory = document.querySelector('.category-filter.active')?.getAttribute('data-category') || 'all';

                analysisItems.forEach(item => {
                    const analysisName = item.getAttribute('data-name');
                    const itemCategory = item.getAttribute('data-category');

                    // Check if matches search
                    const matchesSearch = analysisName.includes(searchTerm);

                    // Check if matches category filter
                    const matchesCategory = activeCategory === 'all' || itemCategory === activeCategory;

                    // Show only if matches both
                    if (matchesSearch && matchesCategory) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });

                updateCount();
            });
        }

        // Kateqoriya filtri
        const categoryFilters = document.querySelectorAll('.category-filter');
        const categoryTitle = document.getElementById('categoryTitle');

        categoryFilters.forEach(filter => {
            filter.addEventListener('click', function() {
                // Remove active from all
                categoryFilters.forEach(f => f.classList.remove('active'));
                // Add active to clicked
                this.classList.add('active');

                const selectedCategory = this.getAttribute('data-category');
                const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

                // Update title
                if (selectedCategory === 'all') {
                    categoryTitle.textContent = 'Bütün Analizlər';
                } else {
                    categoryTitle.textContent = selectedCategory;
                }

                analysisItems.forEach(item => {
                    const itemCategory = item.getAttribute('data-category');
                    const analysisName = item.getAttribute('data-name');

                    // Check category match
                    const matchesCategory = selectedCategory === 'all' || itemCategory === selectedCategory;

                    // Check search match
                    const matchesSearch = !searchTerm || analysisName.includes(searchTerm);

                    // Show only if matches both
                    if (matchesCategory && matchesSearch) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });

                updateCount();
            });
        });

        // Hamısını seç / Heç birini düyməsi
        const selectAllBtn = document.getElementById('selectAllBtn');
        const deselectAllBtn = document.getElementById('deselectAllBtn');

        if (selectAllBtn) {
            selectAllBtn.addEventListener('click', function() {
                // Get only visible checkboxes
                const visibleCheckboxes = Array.from(document.querySelectorAll('.analysis-checkbox'))
                    .filter(checkbox => checkbox.closest('.analysis-item').style.display !== 'none');

                visibleCheckboxes.forEach(checkbox => {
                    checkbox.checked = true;
                });

                updateCount();
            });
        }

        if (deselectAllBtn) {
            deselectAllBtn.addEventListener('click', function() {
                // Get only visible checkboxes
                const visibleCheckboxes = Array.from(document.querySelectorAll('.analysis-checkbox'))
                    .filter(checkbox => checkbox.closest('.analysis-item').style.display !== 'none');

                visibleCheckboxes.forEach(checkbox => {
                    checkbox.checked = false;
                });

                updateCount();
            });
        }

        // Seçilmiş analizlərin sayını göstər
        function updateCount() {
            const checkedCount = document.querySelectorAll('.analysis-checkbox:checked').length;
            const totalCount = document.querySelectorAll('.analysis-checkbox').length;

            selectedCountEl.textContent = `${checkedCount} / ${totalCount} seçildi`;
        }

        document.querySelectorAll('.analysis-checkbox').forEach((checkbox) => {
            checkbox.addEventListener('change', updateCount);
        });

        // Initial count
        updateCount();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/doctor/referrals/create.blade.php ENDPATH**/ ?>