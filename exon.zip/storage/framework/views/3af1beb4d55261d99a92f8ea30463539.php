<?php $__env->startSection('title', 'Raporlar'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="mb-4">
        <h2>Admin Raporları</h2>
        <p class="text-muted">Sistem üzrə mühüm raporları görüntüləyin və Excel formatında yükləyin</p>
    </div>

    <!-- Report Selection and Date Range -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-funnel"></i> Raport Filtri</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.reports.generate')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row g-3">
                    <div class="col-md-12">
                        <label for="report_type" class="form-label">Raport Növü <span class="text-danger">*</span></label>
                        <select class="form-control <?php $__errorArgs = ['report_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="report_type"
                                name="report_type"
                                required>
                            <option value="">Raport seçin...</option>

                            <optgroup label="Maliyyə Raporları">
                                <option value="financial-summary" <?php echo e(old('report_type', $reportType ?? '') == 'financial-summary' ? 'selected' : ''); ?>>
                                    Ümumi Maliyyə Hesabatı
                                </option>
                                <option value="daily-revenue" <?php echo e(old('report_type', $reportType ?? '') == 'daily-revenue' ? 'selected' : ''); ?>>
                                    Günlük Gəlir
                                </option>
                                <option value="monthly-revenue" <?php echo e(old('report_type', $reportType ?? '') == 'monthly-revenue' ? 'selected' : ''); ?>>
                                    Aylıq Gəlir
                                </option>
                            </optgroup>

                            <optgroup label="Xəstə Raporları">
                                <option value="patient-statistics" <?php echo e(old('report_type', $reportType ?? '') == 'patient-statistics' ? 'selected' : ''); ?>>
                                    Xəstə Statistikası
                                </option>
                                <option value="repeat-patients" <?php echo e(old('report_type', $reportType ?? '') == 'repeat-patients' ? 'selected' : ''); ?>>
                                    Təkrar Müraciət Edən Xəstələr
                                </option>
                            </optgroup>

                            <optgroup label="Analiz Raporları">
                                <option value="popular-analyses" <?php echo e(old('report_type', $reportType ?? '') == 'popular-analyses' ? 'selected' : ''); ?>>
                                    Ən Populyar Analizlər
                                </option>
                                <option value="analysis-revenue" <?php echo e(old('report_type', $reportType ?? '') == 'analysis-revenue' ? 'selected' : ''); ?>>
                                    Analizlərin Gəliri
                                </option>
                                <option value="analysis-by-category" <?php echo e(old('report_type', $reportType ?? '') == 'analysis-by-category' ? 'selected' : ''); ?>>
                                    Analiz Növü üzrə Qruplaşdırma
                                </option>
                                <option value="doctor-analysis-category" <?php echo e(old('report_type', $reportType ?? '') == 'doctor-analysis-category' ? 'selected' : ''); ?>>
                                    Doktorların Analiz Növü üzrə Göndərişləri
                                </option>
                            </optgroup>

                            <optgroup label="Həkim Performans Raporları">
                                <option value="doctor-performance" <?php echo e(old('report_type', $reportType ?? '') == 'doctor-performance' ? 'selected' : ''); ?>>
                                    Həkim Performans Raporu
                                </option>
                                <option value="doctor-ranking" <?php echo e(old('report_type', $reportType ?? '') == 'doctor-ranking' ? 'selected' : ''); ?>>
                                    Həkim Performans Rankınq
                                </option>
                            </optgroup>

                            <optgroup label="Endirim və Əməliyyat">
                                <option value="discount-report" <?php echo e(old('report_type', $reportType ?? '') == 'discount-report' ? 'selected' : ''); ?>>
                                    Endirim Statistikası
                                </option>
                                <option value="referral-status" <?php echo e(old('report_type', $reportType ?? '') == 'referral-status' ? 'selected' : ''); ?>>
                                    Göndəriş Statusu Raporu
                                </option>
                            </optgroup>
                        </select>
                        <?php $__errorArgs = ['report_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div id="date-range-section" class="row g-3 mt-2" style="display: <?php echo e(isset($reportType) ? 'flex' : 'none'); ?>;">
                    <div class="col-md-5">
                        <label for="start_date" class="form-label">Başlanğıc Tarixi <span class="text-danger">*</span></label>
                        <input type="date"
                               class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="start_date"
                               name="start_date"
                               value="<?php echo e(old('start_date', $startDate ?? '')); ?>">
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-5">
                        <label for="end_date" class="form-label">Son Tarix <span class="text-danger">*</span></label>
                        <input type="date"
                               class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="end_date"
                               name="end_date"
                               value="<?php echo e(old('end_date', $endDate ?? '')); ?>">
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search"></i> Raporla
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('report_type').addEventListener('change', function() {
            const dateRangeSection = document.getElementById('date-range-section');
            if (this.value) {
                dateRangeSection.style.display = 'flex';
            } else {
                dateRangeSection.style.display = 'none';
            }
        });
    </script>

    <!-- Report Results -->
    <?php if(isset($reportData) && isset($reportType)): ?>
        <div class="mb-3 text-end">
            <a href="<?php echo e(route('admin.reports.export', ['report_type' => $reportType, 'start_date' => $startDate, 'end_date' => $endDate])); ?>"
               class="btn btn-success"
               target="_blank">
                <i class="bi bi-file-earmark-excel"></i> Excel-ə Köçür
            </a>
        </div>

        <?php if($reportType == 'financial-summary'): ?>
            <?php echo $__env->make('admin.reports.partials.financial-summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'daily-revenue'): ?>
            <?php echo $__env->make('admin.reports.partials.daily-revenue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'monthly-revenue'): ?>
            <?php echo $__env->make('admin.reports.partials.monthly-revenue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'patient-statistics'): ?>
            <?php echo $__env->make('admin.reports.partials.patient-statistics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'repeat-patients'): ?>
            <?php echo $__env->make('admin.reports.partials.repeat-patients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'popular-analyses'): ?>
            <?php echo $__env->make('admin.reports.partials.popular-analyses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'analysis-revenue'): ?>
            <?php echo $__env->make('admin.reports.partials.analysis-revenue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'analysis-by-category'): ?>
            <?php echo $__env->make('admin.reports.partials.analysis-by-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'doctor-performance'): ?>
            <?php echo $__env->make('admin.reports.partials.doctor-performance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'doctor-ranking'): ?>
            <?php echo $__env->make('admin.reports.partials.doctor-ranking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'discount-report'): ?>
            <?php echo $__env->make('admin.reports.partials.discount-report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'referral-status'): ?>
            <?php echo $__env->make('admin.reports.partials.referral-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($reportType == 'doctor-analysis-category'): ?>
            <div class="card">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-file-earmark-bar-graph"></i> Doktorların Analiz Növü üzrə Göndərişləri</h5>
                    <a href="<?php echo e(route('admin.reports.doctor-analysis-category.export', ['start_date' => $startDate, 'end_date' => $endDate])); ?>"
                       class="btn btn-light btn-sm"
                       target="_blank">
                        <i class="bi bi-file-earmark-excel"></i> Excel-ə Köçür
                    </a>
                </div>
            <div class="card-body">
                <p class="text-muted mb-3">
                    <i class="bi bi-calendar-range"></i>
                    Tarix aralığı: <strong><?php echo e(\Carbon\Carbon::parse($startDate)->format('d.m.Y')); ?></strong> -
                    <strong><?php echo e(\Carbon\Carbon::parse($endDate)->format('d.m.Y')); ?></strong>
                </p>

                <?php if(count($reportData) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Doktor</th>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($category->name); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th class="text-center">CƏMI</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="fw-bold"><?php echo e($data['doctor']->name); ?></td>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center">
                                                <?php
                                                    $count = $data['categories'][$category->id]['count'] ?? 0;
                                                ?>
                                                <?php echo e($count); ?>

                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td class="text-center">
                                            <strong><?php echo e($data['total']); ?></strong>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>ÜMUMI</th>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center">
                                            <?php
                                                $categoryTotal = 0;
                                                foreach($reportData as $data) {
                                                    $categoryTotal += $data['categories'][$category->id]['count'] ?? 0;
                                                }
                                            ?>
                                            <strong><?php echo e($categoryTotal); ?></strong>
                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th class="text-center">
                                        <?php
                                            $grandTotal = 0;
                                            foreach($reportData as $data) {
                                                $grandTotal += $data['total'];
                                            }
                                        ?>
                                        <strong><?php echo e($grandTotal); ?></strong>
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i>
                        Seçilən tarix aralığında heç bir məlumat tapılmadı.
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>