<?php $__env->startSection('title', 'İstifadəçilər'); ?>

<?php $__env->startSection('nav-menu'); ?>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Ana Səhifə</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.users')); ?>">İstifadəçilər</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.analyses')); ?>">Analizlər</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.settings')); ?>">Ayarlar</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h1 class="fw-bold text-dark mb-2">İstifadəçilər</h1>
        <p class="text-muted">Sistem istifadəçilərini idarə edin</p>
    </div>

    <div class="mb-3 d-flex justify-content-between align-items-center gap-3 flex-wrap">
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-lg" style="background: linear-gradient(135deg, #2D9B6C 0%, #1e7e4f 100%); color: white; border: none;">
            <i class="bi bi-person-plus"></i> Yeni İstifadəçi
        </a>

        <form method="GET" action="<?php echo e(route('admin.users')); ?>" class="d-flex gap-2 flex-grow-1" style="max-width: 500px;">
            <div class="input-group">
                <span class="input-group-text bg-white border-end-0">
                    <i class="bi bi-search text-muted"></i>
                </span>
                <input 
                    type="text" 
                    name="search" 
                    class="form-control border-start-0" 
                    placeholder="Ad, soyad, username, email və ya telefon..." 
                    value="<?php echo e(request('search')); ?>"
                >
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-search"></i> Axtar
            </button>
            <?php if(request('search')): ?>
                <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-x-circle"></i>
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if($users->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="fw-semibold">ID</th>
                                <th class="fw-semibold">Ad Soyad</th>
                                <th class="fw-semibold d-none d-md-table-cell">Email</th>
                                <th class="fw-semibold d-none d-lg-table-cell">Telefon</th>
                                <th class="fw-semibold d-none d-xl-table-cell">Xəstəxana</th>
                                <th class="fw-semibold d-none d-xl-table-cell">Vəzifə</th>
                                <th class="fw-semibold">Rol</th>
                                <th class="fw-semibold d-none d-lg-table-cell">Qeydiyyat</th>
                                <th class="fw-semibold">Əməliyyat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="fw-bold text-primary">#<?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->name); ?> <?php echo e($user->surname); ?></td>
                                    <td class="d-none d-md-table-cell"><small class="text-muted"><?php echo e($user->email); ?></small></td>
                                    <td class="d-none d-lg-table-cell"><?php echo e($user->phone ?? '-'); ?></td>
                                    <td class="d-none d-xl-table-cell"><?php echo e($user->hospital ?? '-'); ?></td>
                                    <td class="d-none d-xl-table-cell"><?php echo e($user->position ?? '-'); ?></td>
                                    <td>
                                        <?php if($user->role): ?>
                                            <span class="badge bg-warning text-dark"><?php echo e($user->role->display_name); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="d-none d-lg-table-cell"><small class="text-muted"><?php echo e($user->created_at->format('d.m.Y')); ?></small></td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-sm btn-success" title="Redaktə">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <?php if($user->id !== Auth::id()): ?>
                                                <form action="<?php echo e(route('admin.users.delete', $user->id)); ?>" method="POST" class="d-inline delete-form\" data-user-name="<?php echo e($user->full_name); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button" class="btn btn-sm btn-danger delete-btn" title="Sil">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-3">
                    <?php echo e($users->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center text-muted py-5">
                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                    <p>İstifadəçi yoxdur</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Modern delete confirmation
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const form = this.closest('.delete-form');
            const userName = form.dataset.userName;

            // Create modern confirmation modal
            if (confirm(`${userName} adlı istifadəçini silmək istədiyinizdən əminsiniz?\n\nBu əməliyyat geri alına bilməz!`)) {
                // Disable button and show loading
                this.disabled = true;
                this.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/admin/users/index.blade.php ENDPATH**/ ?>