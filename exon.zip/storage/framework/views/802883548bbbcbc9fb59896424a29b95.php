<?php $__env->startSection('title', 'Analizlər'); ?>

<?php $__env->startSection('nav-menu'); ?>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Ana Səhifə</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.users')); ?>">İstifadəçilər</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.analyses')); ?>">Analizlər</a></li>
    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.settings')); ?>">Ayarlar</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h1 class="fw-bold text-dark mb-2"><i class="bi bi-clipboard-data"></i> Analizlər</h1>
        <p class="text-muted">Sistem analiz növlərini idarə edin</p>
    </div>

    <div class="mb-3">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <a href="<?php echo e(route('admin.analyses.create')); ?>" class="btn btn-lg" style="background: linear-gradient(135deg, #2D9B6C 0%, #1e7e4f 100%); color: white; border: none;">
                <i class="bi bi-plus-circle"></i> Yeni Analiz
            </a>
            <form method="GET" action="<?php echo e(route('admin.analyses')); ?>" class="d-flex gap-2 align-items-center">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="show_inactive" id="showInactive" 
                           value="1" <?php echo e(request('show_inactive') ? 'checked' : ''); ?> onchange="this.form.submit()">
                    <label class="form-check-label" for="showInactive">
                        Aktiv olmayanları göstər
                    </label>
                </div>
                <input type="text" name="search" class="form-control" placeholder="Analiz adı, özel kod və ya təsvir..." 
                       value="<?php echo e(request('search')); ?>" style="min-width: 300px;">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Axtar</button>
                <?php if(request('search') || request('show_inactive')): ?>
                    <a href="<?php echo e(route('admin.analyses')); ?>" class="btn btn-outline-secondary">Təmizlə</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
        <?php if($analyses->count() > 0): ?>
            <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="fw-semibold">ID</th>
                        <th class="fw-semibold">Özel Kod</th>
                        <th class="fw-semibold">Ad</th>
                        <th class="fw-semibold d-none d-lg-table-cell">Analiz Növü</th>
                        <th class="fw-semibold d-none d-md-table-cell">Təsvir</th>
                        <th class="fw-semibold">Qiymət</th>
                        <th class="fw-semibold d-none d-lg-table-cell">Komisyon</th>
                        <th class="fw-semibold">Status</th>
                        <th class="fw-semibold d-none d-md-table-cell">Yaradılma</th>
                        <th class="fw-semibold">Əməliyyat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $analyses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e(!$analysis->is_active ? 'table-danger' : ''); ?>">
                            <td><span class="badge bg-secondary">#<?php echo e($analysis->id); ?></span></td>
                            <td>
                                <?php if($analysis->ozel_kod): ?>
                                    <span class="badge bg-info-subtle text-info border border-info"><?php echo e($analysis->ozel_kod); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="fw-semibold <?php echo e(!$analysis->is_active ? 'text-danger' : ''); ?>"><?php echo e($analysis->name); ?></td>
                            <td class="d-none d-lg-table-cell">
                                <?php if($analysis->category): ?>
                                    <span class="badge <?php echo e($analysis->category->is_active ? 'bg-info' : 'bg-danger'); ?>">
                                        <?php echo e($analysis->category->name); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="d-none d-md-table-cell text-muted"><?php echo e(Str::limit($analysis->description, 50)); ?></td>
                            <td class="fw-bold <?php echo e(!$analysis->is_active ? 'text-danger' : 'text-success'); ?>"><?php echo e(number_format($analysis->price, 2)); ?> AZN</td>
                            <td class="d-none d-lg-table-cell"><span class="badge bg-warning text-dark"><?php echo e($analysis->commission_percentage); ?>%</span></td>
                            <td>
                                <?php if($analysis->is_active): ?>
                                    <span class="badge bg-success">Aktiv</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Deaktiv</span>
                                <?php endif; ?>
                            </td>
                            <td class="d-none d-md-table-cell text-muted"><?php echo e($analysis->created_at->format('d.m.Y')); ?></td>
                            <td>
                                <div class="d-flex gap-1">
                                    <a href="<?php echo e(route('admin.analyses.edit', $analysis->id)); ?>" class="btn btn-sm btn-success" title="Redaktə"><i class="bi bi-pencil"></i></a>
                                    <form action="<?php echo e(route('admin.analyses.delete', $analysis->id)); ?>" method="POST" class="d-inline delete-form" data-analysis-name="<?php echo e($analysis->name); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-sm btn-danger delete-btn" title="Sil"><i class="bi bi-trash"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>

            <div class="mt-3">
                <?php echo e($analyses->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center text-muted py-5">
                <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                <p>Analiz yoxdur</p>
            </div>
        <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Modern delete confirmation
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const form = this.closest('.delete-form');
            const analysisName = form.dataset.analysisName;

            // Create modern confirmation modal
            if (confirm(`${analysisName} adlı analizi silmək istədiyinizdən əminsiniz?\n\nBu əməliyyat geri alına bilməz!`)) {
                // Disable button and show loading
                this.disabled = true;
                this.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/admin/analyses/index.blade.php ENDPATH**/ ?>