<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold" style="color: #1e7e4f;"><i class="bi bi-chat-dots"></i> Mesajlar</h3>
            <p class="text-muted mb-0">
                <?php if(Auth::user()->isDoctor()): ?>
                    Qeydiyyatçılarla mesajlaşma
                <?php else: ?>
                    Doktorlarla mesajlaşma
                <?php endif; ?>
            </p>
        </div>
        <?php if(Auth::user()->isRegistrar()): ?>
            <div>
                <?php if(request()->has('all')): ?>
                    <a href="<?php echo e(route('messages.index')); ?>" class="btn btn-primary">
                        <i class="bi bi-filter"></i> Yalnız Oxunmamışlar
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('messages.index', ['all' => 1])); ?>" class="btn btn-outline-primary">
                        <i class="bi bi-people"></i> Bütün Doktorlar
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if(Auth::user()->isRegistrar()): ?>
        <!-- Axtarış Forması -->
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('messages.index')); ?>" class="row g-3">
                    <?php if(request()->has('all')): ?>
                        <input type="hidden" name="all" value="1">
                    <?php endif; ?>
                    <div class="col-md-10">
                        <input
                            type="text"
                            name="search"
                            class="form-control"
                            placeholder="Doktor adı və ya soyadı ilə axtarış..."
                            value="<?php echo e(request('search')); ?>"
                        >
                    </div>
                    <div class="col-md-2">
                        <?php if(request('search')): ?>
                            <a href="<?php echo e(route('messages.index', request()->has('all') ? ['all' => 1] : [])); ?>" class="btn btn-secondary w-100">
                                <i class="bi bi-x-circle"></i> Təmizlə
                            </a>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> Axtar
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('messages.show', $conversation['user']->id)); ?>"
                           class="text-decoration-none">
                            <div class="conversation-item p-3 border-bottom <?php echo e($conversation['unread_count'] > 0 ? 'bg-light' : ''); ?>"
                                 style="transition: all 0.3s ease;">
                                <div class="d-flex align-items-start gap-3">
                                    <div class="flex-shrink-0">
                                        <div class="rounded-circle d-flex align-items-center justify-content-center"
                                             style="width: 50px; height: 50px; background: linear-gradient(135deg, #2D9B6C 0%, #1e7e4f 100%);">
                                            <span class="text-white fw-bold">
                                                <?php echo e(strtoupper(substr($conversation['user']->name, 0, 1))); ?><?php echo e(strtoupper(substr($conversation['user']->surname, 0, 1))); ?>

                                            </span>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-start mb-1">
                                            <h6 class="mb-0 fw-semibold text-dark">
                                                <?php echo e($conversation['user']->name); ?> <?php echo e($conversation['user']->surname); ?>

                                                <?php if($conversation['unread_count'] > 0): ?>
                                                    <span class="badge bg-success ms-2"><?php echo e($conversation['unread_count']); ?></span>
                                                <?php endif; ?>
                                            </h6>
                                            <?php if($conversation['last_message']): ?>
                                                <small class="text-muted"><?php echo e($conversation['last_message']->created_at->diffForHumans()); ?></small>
                                            <?php endif; ?>
                                        </div>
                                        <div class="small text-muted">
                                            <i class="bi bi-envelope"></i> <?php echo e($conversation['user']->email); ?>

                                            <?php if($conversation['user']->hospital): ?>
                                                <span class="ms-2"><i class="bi bi-hospital"></i> <?php echo e($conversation['user']->hospital); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($conversation['last_message']): ?>
                                            <p class="mb-0 mt-2 text-muted small">
                                                <strong><?php echo e($conversation['last_message']->sender_id == Auth::id() ? 'Siz:' : ''); ?></strong>
                                                <?php echo e(Str::limit($conversation['last_message']->message, 60)); ?>

                                            </p>
                                        <?php else: ?>
                                            <p class="mb-0 mt-2 text-muted small fst-italic">Hələ mesaj yoxdur</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1"></i>
                            <div class="mt-3">Mesajlaşa biləcəyiniz istifadəçi yoxdur</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .conversation-item:hover {
        background: rgba(45, 155, 108, 0.05) !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/messages/index.blade.php ENDPATH**/ ?>