<?php $__env->startSection('title', 'Analiz Növləri'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Analiz Növləri</h2>
        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Yeni Analiz Növü
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Ad</th>
                            <th>Açıqlama</th>
                            <th>Analiz Sayı</th>
                            <th>Status</th>
                            <th>Əməliyyatlar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e(!$category->is_active ? 'table-danger' : ''); ?>">
                                <td>
                                    <strong class="<?php echo e(!$category->is_active ? 'text-danger' : ''); ?>">
                                        <?php echo e($category->name); ?>

                                    </strong>
                                </td>
                                <td><?php echo e($category->description ?? '-'); ?></td>
                                <td>
                                    <span class="badge bg-info"><?php echo e($category->analyses_count); ?></span>
                                </td>
                                <td>
                                    <?php if($category->is_active): ?>
                                        <span class="badge bg-success">Aktiv</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Deaktiv</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"
                                           class="btn btn-sm btn-success" title="Redaktə">
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <form action="<?php echo e(route('admin.categories.delete', $category->id)); ?>"
                                              method="POST"
                                              class="d-inline"
                                              onsubmit="return confirm('Bu analiz növünü silmək istədiyinizdən əminsiniz?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" title="Sil">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    Hələ heç bir analiz növü əlavə edilməyib
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($categories->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\exon\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>